import {DataState} from "./state";

export const initialDataState: DataState = {
  recipes: [],
  users: []
};