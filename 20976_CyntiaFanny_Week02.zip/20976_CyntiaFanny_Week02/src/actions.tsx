import {dataRecipes, dataUsers} from "./data";

export const getAllRecipes = () => {
  return dataRecipes;
};

export const getAllUsers = () => {
  return dataUsers;
};
